class Logger:
    @staticmethod
    def info(
            *args,
    ):
        print(
            *args,
        )

    @staticmethod
    def warning(
            *args,
    ):
        print(
            *args,
        )

    @staticmethod
    def error(
            *args,
    ):
        print(
            *args,
        )
