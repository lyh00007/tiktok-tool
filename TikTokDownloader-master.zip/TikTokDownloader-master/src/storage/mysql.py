from .sql import BaseSQLLogger

__all__ = ["MySQLLogger"]


class MySQLLogger(BaseSQLLogger):
    pass
